<?php

    $server = "localhost";
    $username = "root";
    $password = "";
    $dbname = "peakflow_tms";

    $conn = new mysqli($server, $username, $password, $dbname);

    // if($conn)
    // {
    //     echo "Connection Success";
    // }

?>